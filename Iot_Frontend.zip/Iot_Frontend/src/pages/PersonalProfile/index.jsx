import React from 'react';

function PersonalProfile() {
    return (
        <div>

        </div>
    );
}

export default PersonalProfile;