import React from 'react'
import { ActivityLog } from './Components/ActivityLog.jsx'

const Report = () => {
    return (
        <div>
            <div className='px-4 py-4'>
                <ActivityLog />

            </div>
            {/* <DashBoard /> */}

        </div>
    )
}

export default Report
