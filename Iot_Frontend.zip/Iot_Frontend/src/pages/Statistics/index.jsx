import React from 'react'

import DashBoard from './Components/DashBoard.jsx'

const Statistics = () => {
  return (
    <div>
      <DashBoard/>
    </div>
  )
}

export default Statistics
