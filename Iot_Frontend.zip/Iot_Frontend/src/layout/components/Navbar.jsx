import React from 'react'

const Navbar = () => {
  return (
    <div className='bg-[#009BE5] h-[180px] text-right'>
      <h1 className='text-white text-2xl'>Danh sách thí nghiệm</h1>
    </div>
  )
}

export default Navbar
